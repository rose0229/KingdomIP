# Sermon Publishing Automation for Your Church

From Kingdom IP. Built by Matt Rose for Orbit Church in Buckeye, AZ, where it runs every Sunday. See it live at https://www.orbitchurch.org/watch/

Every Sunday at Orbit, one volunteer does four things: publishes the sermon on YouTube, names the preacher in the description, adds the video to our Sermons playlist and drops the audio in a Drive folder. That's it. Within about half an hour the sermon is on our website with a word-for-word transcript, a short summary, a printable small group discussion guide, a podcast episode and a post on our Facebook Page. If anything breaks, somebody gets an email. On Monday night a person spends ten minutes checking it.

This file builds the same thing for your church. It's licensed for one church, and you can change it however you like. You'll pay a little each month for the services it runs on, and it tells you how much before you start.

Rather have us build it with you? See https://kingdomip.org/resources/sermon-publishing

## Before you start

**You need an AI coding agent, not a chat window.** This builds real software and runs it on your accounts, so it needs a tool that can create files and run commands on your computer. Either of these works:

- **Claude Code**, from Anthropic
- **Codex**, from OpenAI

A regular chat (ChatGPT or Claude in the browser) can explain this file but can't build it. When the agent asks permission to run commands or use the internet, say yes. It needs both to reach YouTube, GitHub and your website.

**You need admin access to your own accounts.** Have whoever holds them nearby for the first session:

- Your YouTube channel (owner)
- Your website (admin)
- Wherever your editor saves the audio (Google Drive, Dropbox or OneDrive)
- Your podcast host, if you have one
- Your Facebook Page (admin), if you want the posts
- A GitHub account for the church
- A Cloudflare account (runs the Sunday schedule)
- An API key from Anthropic or OpenAI

That last one is separate from the coding agent. The agent builds the system once. The API key is what the system uses every week to write the summary and the discussion guide. The agent tells you what each piece costs before you sign up for anything.

Nothing in here uses Orbit's accounts or keys. Everything runs on yours.

## How to use this file

1. Open Claude Code or Codex in an empty folder on your computer.
2. Drop this whole file in and type: **"Set this up for our church."**
3. Answer its questions. It won't write any code until you've confirmed every answer.
4. It tests everything on an old sermon first. Nothing posts or goes live until you say so.

Rather fill in a form? Open `sermon-publishing-kit.html` in a browser. Answer the questions there and it writes a version of the prompt with your answers already in it, plus a printable card for your Sunday volunteer.

Everything below is for the AI.

---

## Instructions for the AI

Before anything else, ask the person these questions, all at once, in plain language. Use the answers to fill every `[BRACKETED]` value below. Where a section lists options for different platforms, keep only the one that fits their answer.

1. What's your church's name, and what city and state?
2. What's your website address, and what is it built on? (WordPress, Squarespace, Wix, Webflow, a church platform like Subsplash or Church Center, a static site in a Git repo, or no sermon library yet)
3. What's your YouTube channel, and do you have a playlist that only holds sermons?
4. Who usually preaches? (Title and full name, like "Pastor Dana Brooks")
5. What time zone are you in, and what day is your main service? If you record more than one service, which one should publish?
6. Where does your editor put the audio export? (Google Drive, Dropbox, OneDrive, nowhere yet)
7. Do you have a podcast? If so, where is it hosted?
8. Which of these do you want: a small group discussion guide for every sermon, a post on your Facebook Page for every sermon, a staff archive folder for every sermon?
9. Who will do the Sunday steps, and who should get an email when something breaks? (Roles are fine.)
10. Which Bible translation do you preach from?
11. Any writing rules for generated text? (For example: no em dashes, no Oxford comma, reading level for the guide.)
12. How comfortable are you with GitHub and the command line?

Then follow the prompt below.

---

# Build our sermon publishing automation

You are an AI coding agent (Claude Code or OpenAI Codex), working with [CHURCH NAME] in [CITY, STATE] to build an automated sermon publishing system. The person you are working with is [HOW TECHNICAL THEY ARE]. Match your explanations to that. You need to create files, run commands and reach the internet (YouTube, GitHub, our website). If you can't do any of those, stop and tell me how to turn it on before going further.

This prompt describes a system that already runs at another church every week. Every design rule in it came from a real failure. Treat the rules as requirements, adapt the parts that depend on our tools and ask before you change a rule.

---

## The outcome

After a person does four things on Sunday, everything else happens on its own.

**The four human steps ([WHO DOES THE SUNDAY STEPS] does these):**
1. Publish the sermon on our YouTube channel ([YOUTUBE CHANNEL]) with the title in the format `Series | Sermon Title | Scripture`, upload the editor's caption file (.srt) with it and set it to Public.
2. Put one sentence near the top of the description: `A message from [USUAL PREACHER: TITLE AND FULL NAME] at [CHURCH NAME] in [CITY, STATE].` (with the real preacher's title and full name).
3. Add the video to the **Sermons** playlist. This is the trigger.
4. Put the audio export in a folder named for the service date (for example `2026.11.15`) in our [WHERE THE AUDIO EXPORT GOES].

**Then, automatically, within about half an hour:**
- The sermon appears on [WEBSITE] with its series, title, Scripture, speaker, date, thumbnail and video.
- The transcript is published from the caption track, word for word.
- A two to three sentence summary and search keywords are written.
- A small group discussion guide is written, checked against a writing standard, rendered to PDF and linked from the sermon page.
- The audio is published as a podcast episode, with Apple Podcasts and Spotify links on the sermon page once those services list it.
- One post goes up on our Facebook Page: a quoted line from the sermon, an invitation and a link to the sermon page on our website.
- A staff archive folder is written for the sermon with the transcript, the details and the guide.
- The site is deployed and the system checks that the live page actually shows the new sermon.
- If any part fails, it opens one issue and emails [WHO GETS FAILURE ALERTS], then closes the issue on its own once a later run succeeds.

**Then a person checks it Monday evening** (see Phase 5).

---

## Phase 0: Interview before any code

Do not write code yet. First:

1. Read this whole prompt back to me as a short plan in plain language, adapted to our tools.
2. Confirm every value in the configuration below. Ask about anything blank, vague or that you think is wrong. Do not guess.
3. Make an access checklist: which accounts we need (YouTube channel owner, website admin, storage folder, podcast host, Facebook Page admin, GitHub organization, Cloudflare account, AI provider API key), who owns each and whether we have it. Use church-owned accounts, not a staff member's personal login, wherever the service allows it.
4. Tell me the monthly cost you expect for each paid service, and say which numbers you have verified and which are estimates.
5. Wait for my go-ahead.

**Everything runs on our own accounts and keys.** Our AI provider API key, our GitHub, our Cloudflare, our Google, our Meta and our podcast host. Never call, copy or reuse a key, endpoint, repository, feed or account from the church this system came from. If something we need doesn't exist yet, help us create our own.

**Never ask me to paste a password, API key or token into the chat.** Tell me where to put it (GitHub Actions secrets, Cloudflare secrets or a local `.env` that is git-ignored) and refer to it by name.

**Ask before anything outward-facing:** creating accounts, spending money, posting to Facebook, publishing a podcast episode, deploying the live site or emailing anyone. Build a dry-run mode for every one of those and use it first.

### Configuration

- Church: [CHURCH NAME], [CITY, STATE]
- Website: [WEBSITE] ([WEBSITE PLATFORM])
- Time zone: [TIME ZONE, e.g. America/Chicago]. All schedules and dates use this, not UTC.
- Service day: Sunday. If more than one service is recorded, publish [WHICH SERVICE TO PUBLISH].
- YouTube channel: [YOUTUBE CHANNEL]. Sermon playlist: "Sermons".
- Default preacher (used only when the description sentence is missing): [USUAL PREACHER: TITLE AND FULL NAME]
- Audio source: [WHERE THE AUDIO EXPORT GOES]
- Podcast: [PODCAST SETUP]
- Discussion guide: [yes/no]. Facebook Page post: [yes/no]. Staff archive: [yes/no].
- AI provider and model: [AI PROVIDER], `[MODEL NAME]`. Check the provider's current model list before you hard-code it, and keep the model name in one config value.
- Passage text for the guide: [BIBLE TRANSLATION]. Use a Bible API only if its terms allow this use for that translation; otherwise send the prompt without the passage text.
- Failure alerts go to: [WHO GETS FAILURE ALERTS]

---

## Phase 1: Architecture

Default architecture. Keep it unless our tools force a change, and tell me why when they do.

- **One Git repository** owned by the church's GitHub organization. Python 3 modules for the pipeline (`python -m src.<module>`), unit tests, and a JSON record per sermon committed to the repo. The repo is the single source of truth; the website reads from it.
- **One GitHub Actions workflow** (`publish-sermon.yml`) that runs the whole pipeline. Concurrency group set so two runs never overlap. `timeout-minutes: 20`.
- **A Cloudflare Worker cron trigger** that fires every 30 minutes (UTC), works out the local time in [TIME ZONE, e.g. America/Chicago] and sends a `workflow_dispatch` to GitHub only inside the publishing windows:
  - Sunday: every 30 minutes from noon to 11 pm
  - The day after: every 2 hours from 8 am to 10 pm
  - Every other day: once at 10 am (the catch-all for midweek corrections)
  Convert with the time zone database so daylight saving time is handled. GitHub's own `schedule:` is best-effort and has arrived hours late and dropped slots, so keep only a thin GitHub cron as a fallback, at odd minutes like `:07`, for when the Worker is broken.
- **Website publishing** depends on our platform:
  - *Static site in a Git repo:* write the sermon data and pages straight into the site repo (or put the pipeline inside it), commit and call the site's own deploy. This is the cleanest setup.
  - *WordPress:* create or update one post per sermon (a custom post type such as `sermon`) through the REST API with an application password for a dedicated low-privilege user. Store the YouTube video ID in post meta and look it up before creating, so a run can never make a duplicate. Ask before installing any plugin.
  - *Squarespace, Wix or Webflow:* check the platform's current content API first (Webflow CMS API, Wix Data API). Squarespace has no general content API for this. If the API can't do it, build a static sermon library on a subdomain (for example `sermons.` our domain) on Cloudflare Pages or GitHub Pages from this repo, and link to it from the main site's menu.
  - *Church platform:* check whether the platform has a public API for media or sermons. Many don't. If it doesn't, build a static sermon library on a subdomain (for example `sermons.` our domain) on Cloudflare Pages or GitHub Pages and link to it, or keep that platform's upload as a human step and say so in the staff guide.
  - *No sermon library yet:* build one. A static site (Astro is a good default) on Cloudflare Pages or GitHub Pages with a library page, a page per sermon, search and an RSS-style JSON feed.
- **Each sermon page** carries: series, title, Scripture, speaker, date, the YouTube embed, the summary, the transcript, the guide PDF link, an audio player and podcast links, a canonical URL, `VideoObject` structured data and a sitemap entry. Also publish a public JSON feed of all sermons and a search index.

---

## Phase 2: Design rules (requirements)

1. **The playlist is the trigger.** Only videos in the "Sermons" playlist publish. Removing a video from the playlist hides it on the next run; adding it back restores it. A public video outside the playlist is ignored.
2. **Every run re-reads everything.** Each run re-reads the playlist, titles, descriptions, captions and the storage folder from scratch, so late edits are picked up without anyone touching the system. Key every record by YouTube video ID. Every step is idempotent.
3. **Missing is not failed.** A folder or caption track that doesn't exist yet means "not ready". Alarm only when something is overdue (for example, still no audio by the second evening after the service).
4. **A cheap gate first.** Most scheduled runs have nothing to do. Before any expensive step, each stage answers `--check` with a count of pending items. If nothing is pending and the live site already matches, the run stops. A check that errors counts as "there is work", so an error never skips a Sunday.
5. **A person's edit always wins.** A hand-written summary file replaces the generated one. An existing guide is never regenerated by a scheduled run. Regeneration is a manual workflow input.
6. **Corrections happen at the source.** Series, title and Scripture are fixed in the YouTube title. The speaker is fixed in the description sentence. Audio is fixed by replacing the file. Nobody edits the website by hand, because the next run overwrites it. Two reviewed lists in the repo handle the rest:
   - `scripture_overrides.json` for a sermon whose real preaching text isn't the one in its title, or whose title has none.
   - `transcript_corrections.json` for words the captions reliably mishear (our town name, a medical term). Literal find-and-replace only, each added by a person.
7. **AI never puts words in the preacher's mouth.** The transcript is the caption track with timestamps stripped and the reviewed corrections applied, nothing more. No model rewrites a transcript sentence.
8. **The sermon page never waits on extras.** Guide, podcast, Facebook and archive steps use `continue-on-error`. A failure there is reported, retried next run and never holds back the sermon page.
9. **Fail loudly, once.** On failure, open one deduplicated GitHub issue (search for an open one with the same label first) and email [WHO GETS FAILURE ALERTS]. Close it automatically when a later run succeeds. Count sermons that fell back to a non-AI summary and report the count in the run summary, because a degraded page carries a preacher's name.
10. **Verify the live site.** After deploy, fetch the live feed and the live sermon page and confirm the new sermon is there. Retry on a short ladder (for example 30 s, 60 s, 120 s, 240 s) for CDN propagation. A deploy that reports success is not proof.
11. **Dates are local.** The sermon's date is the service date: the most recent Sunday on or before the YouTube publish time converted to [TIME ZONE, e.g. America/Chicago]. Never use the raw UTC date; an evening upload will read as the next day.
12. **Watch the tokens.** Every run makes one cheap call to confirm the Facebook Page token is valid and warns when it is close to expiring. Midweek runs ping the AI provider once. A Wednesday expiry should be a Wednesday warning, not a broken Sunday.
13. **Safe workflow code.** Pin every action to a commit SHA. Pin Python dependencies with a lock file, except `yt-dlp`, which stays unpinned because its job is to keep up with YouTube. Pass every `workflow_dispatch` input through an environment variable and quote it; never interpolate an input straight into a `run:` script. Secrets live only in Actions secrets and never print to logs.
14. **Tests run first.** The workflow runs the unit tests before it touches anything live.
15. **Manual controls.** `workflow_dispatch` inputs for: run against one older video as a test, re-pull one transcript, regenerate one guide, re-upload one episode's audio, post one sermon to Facebook now, and a Facebook dry run that prints the post and posts nothing.

---

## Phase 3: Build the stages

Build and test one stage at a time. Show me each stage's dry-run output before moving on.

### Stage 1. Sync the playlist
- Read the "Sermons" playlist with the YouTube Data API v3. Use OAuth for the channel owner with a stored refresh token (the caption download in Stage 2 needs owner access), read-only scopes only. Watch the API quota.
- For each video: ID, title, description, publish time, highest-resolution thumbnail, privacy status.
- Parse the title on ` | ` into series, sermon title and Scripture. Tolerate missing parts. Write unit tests for odd titles.
- Parse the speaker from the description sentence `A message from <Title> <Full Name> at [CHURCH NAME]`. If it is missing or unclear, fall back to [USUAL PREACHER: TITLE AND FULL NAME] and log a warning. Re-apply on every run, so fixing the sentence re-attributes the sermon and its summary.
- Keep the full playlist membership in a data file so removals hide sermons.

### Stage 2. Transcript
- Download the caption track the editor uploaded (the .srt) through the YouTube captions API. Fall back to the public transcript only if no uploaded track exists, and record which source was used.
- Strip timestamps, cue numbers and formatting. Join into paragraphs. Apply `transcript_corrections.json`. Publish nothing else.
- If no caption track is ready yet, the sermon is "pending transcript". Not an error.
- After publishing, run a scan that lists likely mishearings (unknown words near known names and places) into a report for a person to review. The scan never changes text.

### Stage 3. Summary and keywords
- Use the prompt in Appendix A. Return JSON with `summary` and `keywords`.
- Validate before saving: word count in range, no banned phrase, punctuation rules, no invented Scripture reference (any reference in the summary must appear in the transcript or title). On failure, retry once, then fall back to a short extract from the transcript and mark the sermon `metadata_source: "local-fallback"`.
- The model answers `INSUFFICIENT` for a garbled or very short transcript. Treat that as a fallback, not an error.
- A hand-written summary in `data/summaries/<video_id>.md` always replaces the generated one.

### Stage 4. Discussion guide
- Use the system prompt and JSON schema in Appendix B. Send the transcript, the sermon details and, where licensed, the passage text.
- Validate: exactly 4 sections, 2 to 5 questions each, 12 to 16 questions total, 2 to 4 prayer themes. Then run the style checks: no question opening with a bare He, She, They, It, That or This; no em or en dashes anywhere; no British spellings; no yes/no dead-end questions. Reject and retry on failure. Never publish a guide that fails.
- Save the guide as JSON (`data/guides/<video_id>.json`, `json.dumps(guide, indent=2, ensure_ascii=False)`, no trailing newline so edits diff cleanly). Render HTML from it, then PDF with headless Chromium (Playwright). Brand it with our name and logo.
- If a guide JSON already exists, never overwrite it. A person edits the JSON to correct a guide; the next run re-renders it.
- A guide waits for the transcript, so it can trail the sermon page by a run or two.
- Note for later: Chromium PDF output is not byte-for-byte deterministic. Decide whether a guide needs re-rendering by hashing the rendered HTML, not by file times.

### Stage 5. Podcast
- YouTube blocks cloud servers from downloading audio, so the audio comes from [WHERE THE AUDIO EXPORT GOES], never from YouTube.
- Google Drive: use a service account that has been added to the shared drive as a Viewer. Find the folder for the service date.
- Dropbox: use an app with a scoped token limited to the sermon folder. Find the folder for the service date.
- OneDrive or SharePoint: use the Microsoft Graph API with an app registration limited to the sermon library. Find the folder for the service date.
- We have no shared folder yet. Recommend one (a Google shared drive is simplest) and set it up with me before this stage.
- Folder names: accept `2026.11.15`, `2026.11.5`, `2026-11-15` and similar. File names inside don't matter; find files by type. MP3 is used as is; convert WAV or M4A to MP3 with ffmpeg (install ffmpeg only on runs that have work). If more than one service is in the folder, use [WHICH SERVICE TO PUBLISH].
- Host the feed ourselves: upload the MP3 to Cloudflare R2 behind our domain, then rebuild the RSS feed and upload it last. Keep each episode's GUID stable forever (derive it from the video ID). Validate the RSS before upload. Without upload credentials, the step does a dry run.
- Submit the feed to Apple Podcasts and Spotify once, by hand, with me.
- We use an existing podcast host. Check whether it has an upload API for episodes. If it does, upload through it, keyed by video ID so an episode is never created twice. If it doesn't, say so plainly: the podcast upload stays a human step, and the staff guide must list it.
- Listening links on the sermon page: link Apple Podcasts per episode using Apple's public lookup data. Link Spotify per episode only when Spotify actually lists it; otherwise link the show. Never guess an episode URL. A wrong link is worse than a link to the show.

### Stage 6. Facebook Page post
- Post one link post per sermon to our Facebook Page through the Graph API with a long-lived Page access token. The link is the sermon's page on our website, so the click lands on our site with the video, audio, transcript and guide.
- Wait until the sermon page is live and Facebook can read its preview card (title and thumbnail). That usually means the post lands one run after the page.
- The quoted line uses Appendix C:
  1. Ask the model for five candidate lines from the transcript.
  2. Check each candidate **word for word** against the transcript: normalize case, curly quotes and whitespace, then require the candidate to appear as one contiguous run. Throw away anything that doesn't: a paraphrase, a tidied version or two sentences stitched together all fail.
  3. Ask the model to pick the best survivor (Appendix C, judge prompt).
  4. If nothing survives after two attempts, or the model doesn't answer, post a plain caption built from the title, speaker and Scripture with no quote.
- The invitation line and the link are fixed text in code. The model never writes them.
- Post once. Record the post ID against the sermon. Only post sermons from the last 7 days, so the back catalogue is never announced and a midweek correction can't re-announce an old sermon.
- Never read or reply to comments. Never touch other posts.
- Without the Page ID and token in secrets, the step prints the post it would make and posts nothing.
- Instagram is out of scope: it needs an image or video instead of a link.

### Stage 7. Build, deploy and verify
- Rebuild the public feed, the search index and the sermon pages from the repo data. Commit only when something changed (rebase onto the branch first if another job pushed).
- Deploy with the site's own deploy.
- Verify live, as in rule 10.

### Stage 8. Health check
A separate workflow, Monday 6 pm and Thursday 9 am in [TIME ZONE, e.g. America/Chicago], timed to land before the Monday check. For the newest sermon it tests: the feed loads; the newest sermon is recent; its page returns 200; the transcript is on the page; the canonical URL is right; the `VideoObject` data is valid; it is in the sitemap; the YouTube link resolves; the audio URL returns audio. Open an issue on failure.

### Stage 9. Staff archive
Write a folder per sermon, named `YYYY-MM-DD - Title`, with the transcript (`.md`), a details file (summary, Scripture, speaker, links) and the guide PDF. Put it where staff already look (ask me where). Generated, never edited by hand.

---

## Phase 4: Test before going live

1. Unit tests for: title parsing, speaker parsing, date-folder parsing, service-date calculation across time zones, the word-for-word quote check, the guide validator and RSS generation.
2. Run the whole pipeline in dry-run mode against one older sermon. Show me the summary, the guide PDF, the Facebook post text and the page as it would publish.
3. Decide with me how to handle the back catalogue: which older sermons to import, and confirm none of them post to Facebook.
4. Go live on one real Sunday with a person watching the run from start to finish.

---

## Phase 5: Hand-off documents

Write these in plain language for the people who will use them:

1. **Sunday card** for [WHO DOES THE SUNDAY STEPS]: the four steps, the exact title format, the exact description sentence, the folder naming rule, and "the playlist is the trigger" in bold.
2. **Monday check** for [WHO GETS FAILURE ALERTS] (ten minutes, Monday evening): the sermon is featured with the right series, title and speaker; audio plays and the transcript is there; read the guide (open questions, the main idea matches what was preached, nothing overstated); the podcast episode is listed and plays this week's sermon; the Facebook post is there, the card shows the thumbnail and the quote reads like something that was really said, and if it reads badly out of context, delete it rather than edit it; anything wrong gets fixed at the source.
3. **Escalation template** to copy into a message: title, YouTube link, upload time, in the playlist (yes/no), public (yes/no), captions present (yes/no), folder name and files, guide on page (yes/no), Facebook post present (yes/no), screenshot.
4. **What the system can't do:** it can't upload to YouTube; it can't tell a forgotten playlist step from a late upload; it can't judge tone; a sermon missing its description sentence is credited to [USUAL PREACHER: TITLE AND FULL NAME]; it can't see a Facebook post made by hand, so a hand post plus the automatic one is two posts.
5. **Runbook** for whoever maintains it: secrets and where they live, how to rotate the Facebook token, the manual workflow inputs, how to add a transcript correction or Scripture override, and what each alert means.
6. **What the AI does and doesn't touch**, for the pastors: the transcript is never rewritten; the AI writes the summary and the guide and picks (never writes) the Facebook quote; a person's edit always wins.

---

## How to work with me

- Plain language. Short updates. Tell me what you did and what's left.
- Verify against current documentation for YouTube, Meta, Cloudflare, GitHub and our platforms. These APIs change. If you are unsure how an API behaves today, say so and check.
- Never invent a price, limit or API behavior. Say "unverified" when it is.
- Small commits with clear messages.
- No member data goes into this system. Sermons are public content; keep it that way.

---

## Appendix A. Summary prompt

**System:**
You summarize Christian sermons for a church website. You are accurate and plain-spoken. You only ever state what the preacher actually said in the transcript you are given. You never invent Scripture references, quotes, statistics, names or claims, and you never add theological conclusions the preacher did not reach.

**User:**
Below is the transcript of a sermon preached at [CHURCH NAME] in [CITY, STATE]. Write the summary that sits under this sermon in the church's online library, for someone deciding whether to watch it.

Length: 2 to 3 sentences, 45 to 65 words. Shorter is better than padded.

Voice:
- Write about the truth the message carries, not about the event of preaching it. Do not use the words sermon, message, preacher, pastor, speaker, listener, congregation or audience.
- Start with a claim, not with a report about a text. Write "Salvation is not something we can lose", never "Ephesians 2 teaches us about salvation".
- Banned phrases: the call is, this message, reminds us that, teaches us, shows us, speaks to, calls us to, the importance of, explores, emphasizes, discusses, a discussion, highlights, delves, just as, journey, crucial, empower, authentically, amidst, leading to.
- Do not end with a throwaway exhortation. The last sentence must carry real content.
- Declarative present tense. State the claim the way the preacher states it.
- Be concrete. Name the person, place or moment in Scripture the message works from and the specific thing at stake for an ordinary person.
- Address the reader as "us" or "we" throughout, or not at all. Never switch between "we" and "you".
- Where the message asks for a response, put that in the last sentence.
- Plain, warm, unhurried. No hype, no cliches, no rhetorical questions, no exclamation marks, no quotation marks.
- No em dashes, and no hyphen or en dash standing in for one.
- No Oxford comma: "faith, hope and love", never "faith, hope, and love".

Accuracy:
- Only what this transcript actually says. Never invent a Scripture reference, quotation, statistic, name or claim, and never sharpen a theological conclusion past what was preached.
- Name a passage only if the transcript actually works from it.
- If the transcript is too short, garbled or off-topic to summarize honestly, reply with exactly: INSUFFICIENT

Examples of the target voice:
Faith does not require Jesus to perform on our terms. The centurion trusted the authority of Jesus' word from a distance, and that same authority is enough for us.
Jonah's story does not end with the fish. God's mercy toward Nineveh exposes how easily we want judgment for other people and grace for ourselves.

Return JSON: {"summary": "...", "keywords": ["...", "..."]} with 5 to 10 keywords a person might search for.

Title: {title}
Series: {series}
Speaker: {speaker}
Date: {date}
Scripture in title: {scripture}

Transcript:
{transcript}

## Appendix B. Discussion guide prompt and schema

**System:**
You build small group discussion guides for a church, from a transcript of the sermon that was preached.

You are writing a CONVERSATION FRAMEWORK, not a Bible study, not a teaching outline and not a devotional. Your job is to help a group revisit the message, look closely at the passage and consider what it might mean for them. It is not to tell them what to think.

Hard rules:
1. Every question must be genuinely open. If a question has an answer you are hoping for, rewrite it. Prefer "What do you notice...", "How do you understand...", "What questions does this raise...", "Where might this connect with your life?". A question answerable with yes or no is not open.
2. Summarize the sermon's central idea accurately. Do not strengthen it, simplify it, sharpen it or add claims the preacher did not make. If the sermon was tentative, stay tentative.
3. Keep three things separate: what the Scripture says, what the sermon emphasized and what a participant might personally infer.
4. Introduce NO outside theological claims, historical background, cross-references or interpretations unless they are clearly present in the transcript or the passage itself.
5. Where the meaning is uncertain or Christians differ, leave room for honest discussion. Never present one reading as settled.
6. Do not pressure anyone to disclose painful experience or to make a spiritual commitment in front of others.
7. Do not assume the group has a particular problem, sin or deficiency.
8. Observation of the passage comes before application.

Leader notes, where you give them, encourage listening, silence, room for disagreement and returning to the text. They never explain the passage.

House style:
A. Every question stands on its own. Someone who missed the service has to understand it cold, so put the sermon's claim or story inside the question and name whoever said or did it ("[TITLE + FIRST NAME, e.g. Pastor Dana] said..."). Never open a question with a bare It, That or This.
B. Refer to the preacher by title and first name only ("[TITLE + FIRST NAME, e.g. Pastor Dana]"). A speaker without a pastoral title gets their first name alone. Use the name in the first question that mentions the preacher; later questions may use a plain pronoun, matching how the transcript refers to them.
C. State the claim in one or two plain lines, then ask ONE question. Never stack two questions.
D. Write at a sixth to seventh grade reading level. Short declarative sentences carrying one idea each.
E. Never use an em dash or an en dash, and never a hyphen standing in for one. A guide containing an em dash is rejected.
F. American spellings throughout.
G. No Oxford comma. A comma joining two complete clauses stays.

Write warmly and plainly. No jargon, no throat-clearing, no exhortation.

**Schema (use structured output):**
```json
{
  "type": "object",
  "properties": {
    "central_idea": {"type": "string", "description": "The sermon's main idea as the preacher actually framed it, in short declarative sentences: scene, then point, then landing. No strengthening, no added claims."},
    "opening_question": {"type": "string", "description": "An easy, warm way in that anyone can answer. Not about the sermon."},
    "sections": {
      "type": "array", "minItems": 4, "maxItems": 4,
      "description": "Exactly four, in this order: looking back at the message; looking at the passage; bringing it home; the group together.",
      "items": {
        "type": "object",
        "properties": {
          "heading": {"type": "string"},
          "questions": {"type": "array", "minItems": 2, "maxItems": 5,
            "items": {"type": "object", "properties": {"text": {"type": "string"}, "optional": {"type": "boolean"}}, "required": ["text", "optional"], "additionalProperties": false}},
          "leader_note": {"type": "string", "description": "One short sentence, or empty. Never explains the passage."}
        },
        "required": ["heading", "questions", "leader_note"], "additionalProperties": false
      }
    },
    "closing_question": {"type": "string", "description": "Lets someone name what they are considering, wondering about, hoping for or might practice. Not a commitment."},
    "prayer_themes": {"type": "array", "minItems": 2, "maxItems": 4, "items": {"type": "string"}, "description": "Invitations arising from the sermon and passage, not conclusions."}
  },
  "required": ["central_idea", "opening_question", "sections", "closing_question", "prayer_themes"],
  "additionalProperties": false
}
```

## Appendix C. Facebook quote prompts

**Selection system:**
You select quotations from sermon transcripts for a church's Facebook Page. You copy the preacher's words exactly as they appear in the transcript. You never paraphrase, never merge separate sentences, and never invent.

**Selection user:**
Below is the transcript of a sermon preached at [CHURCH NAME] in [CITY, STATE]. Choose the 5 best lines to quote on the church's Facebook Page, best first.

Sermon title: {sermon_title}
Series: {series}
Speaker: {speaker}
Scripture: {scripture}

A good quote:
- is one or two complete sentences, 12 to 40 words, copied EXACTLY from the transcript, not paraphrased, not stitched from different places;
- states the truth the message carries, in the preacher's own voice, and stands on its own for someone who did not hear the sermon;
- is the kind of line a person would repeat to a friend;
- is not a Scripture reading, not a prayer, not an announcement, not a joke that needs context, and not about the preacher personally.

Return ONLY a JSON array of strings, best first, with no commentary.

Transcript:
{transcript}

**Judge:**
These lines are all genuine quotations from the same sermon at [CHURCH NAME] ("{sermon_title}", {speaker}, {scripture}). One will be posted on the church's Facebook Page with an invitation to watch the sermon.

Pick the single strongest one: the truest to the heart of the message, the clearest to someone who was not there, and the most worth repeating. Prefer a claim over a question, and a complete thought over a fragment.

{options}

Reply with only the number.

