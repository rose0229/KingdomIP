# Giving Calculator Kit

From Kingdom IP (kingdomip.org).

A giving calculator for your church's give page. It teaches a short theology of tithes and offerings, shows people their giving amount per paycheck, then sends them to your giving page with the amount ready. Built and tested on a live church give page.

What's in this kit:
- `giving-calculator.html`: the calculator, one file
- `giving-calculator-iframe.html`: the embed code for website builders that need it
- this guide

Your purchase covers one church's website. Please don't resell or redistribute it.

## How to use this file

1. Drop this whole file into ChatGPT, Claude or whatever AI you use.
2. Type: **"Set this up for our church."**
3. Answer the questions it asks (church name, giving link, website, colors).
4. It hands you the finished code plus step-by-step instructions. Forward both to your web person.

That's it. Everything below is for the AI and your web person.

---

## Instructions for the AI

You are helping a church add this giving calculator to its website. The person talking to you is probably a pastor, not a developer. Your job is to produce a finished, customized calculator and a handoff note their web person can follow.

### Step 1. Ask these questions, all at once, in plain language

1. What's your church's name?
2. What's the link to your online giving page?
3. Which giving platform do you use? (Planning Center, Pushpay, Tithe.ly, Subsplash, other)
4. What do you use to build your website? (ChurchCo, Squarespace, Wix, WordPress, other, or "not sure")
5. What's your website address? (So the calculator can match your colors and fonts.)
6. Do you want to keep the theology section as written, rewrite it in your church's words, or remove it? If rewrite, paste anything you already say about giving.
7. Which Bible translation does your church use?

If they can't answer something, use the defaults already in the code and say which defaults you used. If you can view their website, pull their brand colors and fonts from it. If you can't, ask for their main colors or keep the defaults.

### Step 2. Customize the code

The full code is in the "Calculator code" section below. Every place to edit is marked with a `STEP` comment.

- **STEP 4 (CONFIG in the script):** set `churchName` and `givingUrl`. Set `amountParam` to `"amount"` for Planning Center (Church Center reads `?amount=` and pre-fills the gift). For any other platform, set it to `""` unless you know their platform supports a pre-fill parameter, in which case use that parameter name. Leave `giveButtonText` as "Copy amount and set up a recurring gift". The calculator works out a per-paycheck amount, so the button points people to recurring giving. Don't put the giving platform's name on the button; most church members don't know it. If the church's give page has other buttons that name the platform, suggest changing them to "Give online" too.
- **STEP 2 (`:root` block):** set the brand colors, corner radius and font names. Keep strong contrast: text on the dark card must be easy to read, and text on accent buttons must be readable too.
- **STEP 1:** replace the Google Fonts link with one for their fonts. If their fonts aren't on Google Fonts, remove the link and use system fonts.
- **STEP 3 (theology section):** keep, rewrite or delete as they asked. This wording comes from Orbit Church. It treats the tithe as the Old Testament pattern and a goal to grow toward, with New Testament generosity beyond it. If they rewrite it, use their beliefs, not yours.

### Rules

- Do not change the calculator math.
- Do not remove the privacy note.
- Do not add analytics, tracking, cookies or anything that sends what visitors type to a server.
- Do not load scripts from other websites.
- Keep it working on phones.
- Scripture: quote word for word from the church's translation and label it. If you can't confirm the exact wording of their translation, keep the NIV quote that's already there and its copyright line. Never invent a quote or present a paraphrase as a quote.

### Step 3. Give back three things

1. **The finished code:** one complete HTML file, ready to save as `giving-calculator.html`. Return the whole file, not just the changes.
2. **Handoff note for the web person,** written for their website builder:
   - If the builder accepts a full HTML page or a custom code block that runs scripts (WordPress, most custom sites): how to add it as a page or block.
   - If it doesn't, or they're not sure (ChurchCo, Squarespace, Wix and similar are often in this group): how to host the file (their site's file manager, or Netlify Drop at https://app.netlify.com/drop) and paste the iframe snippet from the "iframe snippet" section below, with the hosted link filled in once they have it.
   - A short test list: click each income button, type an income, move the slider, click both buttons, check it on a phone.
3. **A two-line summary for the pastor** of what you changed and any defaults you used.

Tell the pastor one more thing: the calculator only works once it's on a real web page or opened in a browser like Chrome or Safari. Some file previews (in email, chat apps or AI tools) show the page but don't run it, so the buttons look dead there.

---

## For the web person: what to change

| What | Where in the code | What to put there |
|---|---|---|
| Church name | `STEP 4`, `churchName` | Shows in the privacy note |
| Giving page link | `STEP 4`, `givingUrl` | The page where people give online |
| Amount pre-fill | `STEP 4`, `amountParam` | `"amount"` for Planning Center, `""` for others |
| Button text | `STEP 4`, `giveButtonText` | Default is "Copy amount and set up a recurring gift." Keep the platform name off it |
| Colors and corners | `STEP 2`, the `:root` block | Brand dark color, accent color, page background |
| Fonts | `STEP 1` and `STEP 2` | Google Fonts link and font names |
| Theology section | `STEP 3` | Rewrite, or delete the whole `<section>` |

How it works:

- The math runs in the visitor's browser. Nothing they type goes anywhere. "Copy and store" saves the amount only in their own browser.
- The calculator doesn't create a recurring gift. It sends people to your giving page with the amount ready, and your giving platform handles the recurring setup.
- Annual income shows as a monthly amount. Every other choice shows per paycheck.

---

## Calculator code

```html
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Giving Calculator</title>

<!-- ============================================================
     STEP 1: FONTS (optional)
     Swap this Google Fonts link for your church's fonts, then
     update --font-heading and --font-body below to match.
     ============================================================ -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">

<style>
  /* ============================================================
     STEP 2: BRAND COLORS AND FONTS
     Change these values to match your church. Everything else
     in the stylesheet reads from them.
     ============================================================ */
  :root {
    --brand-dark: #14213d;      /* card background (your darkest brand color) */
    --brand-accent: #e0a526;    /* buttons, slider, dial (your accent color) */
    --brand-accent-text: #14213d; /* text on accent buttons */
    --page-bg: #f6f4ef;         /* page background behind everything */
    --text: #1d1d1f;            /* body text on light background */
    --text-on-dark: #ffffff;    /* text on the dark card */
    --muted-on-dark: rgba(255,255,255,.72);
    --radius: 18px;             /* corner roundness (0px for square) */
    --font-heading: "Inter", system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
    --font-body: "Inter", system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
  }

  * { box-sizing: border-box; }
  html, body { margin: 0; }
  body {
    background: var(--page-bg);
    color: var(--text);
    font-family: var(--font-body);
    line-height: 1.55;
    padding: 24px 16px;
  }
  .wrap { max-width: 960px; margin: 0 auto; display: grid; gap: 24px; }
  h2, h3 { font-family: var(--font-heading); line-height: 1.15; margin: 0 0 .5em; }
  h2 { font-size: clamp(1.6rem, 4vw, 2.3rem); }
  p { margin: 0 0 1em; }
  .eyebrow {
    text-transform: uppercase; letter-spacing: .12em; font-size: .78rem;
    font-weight: 700; margin-bottom: .6em; opacity: .75;
  }

  /* ---------- Theology section ---------- */
  .theology { padding: 8px 0; }
  .theology blockquote {
    margin: 1.2em 0; padding: 1em 1.2em; border-left: 4px solid var(--brand-accent);
    background: rgba(0,0,0,.03); border-radius: 0 var(--radius) var(--radius) 0;
    font-size: 1.1rem;
  }
  .theology cite { display: block; margin-top: .4em; font-style: normal; font-size: .85rem; opacity: .7; }
  .steps { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin: 1.4em 0; }
  .steps div { background: #fff; border-radius: var(--radius); padding: 18px; }
  .steps b { display: block; color: var(--brand-accent); font-size: 1.4rem; font-family: var(--font-heading); }
  .steps h3 { font-size: 1.1rem; margin: .3em 0; }
  .steps p { margin: 0; font-size: .95rem; }

  /* ---------- Calculator card ---------- */
  .calc {
    background: var(--brand-dark); color: var(--text-on-dark);
    border-radius: var(--radius); padding: clamp(20px, 4vw, 40px);
    display: grid; gap: 22px;
  }
  .calc .intro p { color: var(--muted-on-dark); }
  .basis { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 8px; }
  .basis button {
    font: inherit; font-weight: 600; padding: 12px; border-radius: calc(var(--radius) / 2);
    border: 1px solid rgba(255,255,255,.3); background: transparent; color: var(--text-on-dark); cursor: pointer;
  }
  .basis button[aria-pressed="true"] { background: var(--brand-accent); color: var(--brand-accent-text); border-color: var(--brand-accent); }
  label { font-weight: 600; display: block; margin-bottom: 6px; }
  #income {
    width: 100%; font: inherit; font-size: 1.4rem; padding: 14px 16px;
    border-radius: calc(var(--radius) / 2); border: 1px solid rgba(255,255,255,.3);
    background: rgba(255,255,255,.08); color: var(--text-on-dark);
  }
  #income::placeholder { color: rgba(255,255,255,.45); }
  small { display: block; margin-top: 8px; color: var(--muted-on-dark); }
  .control { display: grid; grid-template-columns: auto 1fr; gap: 20px; align-items: center; }
  .dial {
    --percent: 10;
    width: 108px; height: 108px; border-radius: 50%; display: grid; place-items: center;
    background: conic-gradient(var(--brand-accent) calc(var(--percent) * 1%), rgba(255,255,255,.12) 0);
    position: relative;
  }
  .dial::before { content: ""; position: absolute; inset: 10px; border-radius: 50%; background: var(--brand-dark); }
  .dial strong { position: relative; font-size: 1.6rem; font-family: var(--font-heading); }
  .control-label { font-weight: 700; margin-bottom: 4px; }
  input[type="range"] { width: 100%; accent-color: var(--brand-accent); }
  .range-labels { display: flex; justify-content: space-between; font-size: .8rem; color: var(--muted-on-dark); }
  .help { color: var(--muted-on-dark); margin: 10px 0 0; font-size: .95rem; }
  .result { background: rgba(255,255,255,.07); border-radius: var(--radius); padding: 20px; }
  .result-label { margin: 0; color: var(--muted-on-dark); font-weight: 600; }
  .result strong.amount { display: block; font-size: clamp(2.2rem, 7vw, 3.2rem); font-family: var(--font-heading); color: var(--brand-accent); }
  .result p { margin: .4em 0 0; }
  .actions { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 10px; }
  .actions button, .actions a {
    font: inherit; font-weight: 700; text-align: center; text-decoration: none; cursor: pointer;
    padding: 14px 18px; border-radius: 999px;
  }
  .actions button { background: transparent; color: var(--text-on-dark); border: 1px solid rgba(255,255,255,.4); }
  .actions a { background: var(--brand-accent); color: var(--brand-accent-text); border: 1px solid var(--brand-accent); }
  .message { min-height: 1.4em; margin: 0; color: var(--brand-accent); font-weight: 600; }
  .next-step { margin: 0; color: var(--muted-on-dark); font-size: .95rem; }

  @media (max-width: 520px) {
    .control { grid-template-columns: 1fr; justify-items: center; }
    .control > div:last-child { width: 100%; }
  }
</style>
</head>
<body>
<div class="wrap">

  <!-- ============================================================
       STEP 3: THEOLOGY SECTION
       This is Orbit Church's wording. Rewrite it in your own words
       so it matches what your church teaches about giving.
       Delete this whole <section> if you only want the calculator.
       ============================================================ -->
  <section class="theology" aria-labelledby="theology-title">
    <p class="eyebrow">A theology of generosity</p>
    <h2 id="theology-title">When you give, you're trusting God with your finances.</h2>
    <p>The world has a lot to say about how we should spend our wealth. We believe we are managers of God's money, called to earn, spend and give in ways that honor him.</p>
    <p>In the Old Testament, the tithe was a pattern of consistent giving: the best of the first 10% brought to the local storehouse. It was a practice of trusting God to provide rather than living by self-reliance.</p>
    <blockquote>
      "Bring the whole tithe into the storehouse, that there may be food in my house."
      <cite>Malachi 3:10 (NIV)</cite>
    </blockquote>
    <p>The New Testament calls us toward radical, sacrificial generosity. We want to be gracious about the process while staying honest about the standard: start somewhere, move toward the tithe and keep growing as God leads.</p>
    <div class="steps">
      <div><b>01</b><h3>Start somewhere</h3><p>Begin with a faithful, intentional step.</p></div>
      <div><b>02</b><h3>Move toward the tithe</h3><p>Grow toward the Old Testament pattern of 10%.</p></div>
      <div><b>03</b><h3>Increase progressively</h3><p>Practice the radical generosity Jesus forms in us.</p></div>
    </div>
    <p><strong>The 3 P's of biblical generosity:</strong> Make it a Priority. Make it a Percentage. Make it a Progression.</p>
  </section>

  <!-- ============================================================
       THE CALCULATOR (no edits needed below this line except
       STEP 4 in the script)
       ============================================================ -->
  <section class="calc" aria-labelledby="calc-title">
    <div class="intro">
      <p class="eyebrow">Tithing calculator</p>
      <h2 id="calc-title">Build a faithful giving rhythm.</h2>
      <p>Estimate giving from your gross income before taxes. Choose your income rhythm, then adjust the percentage as you consider your next faithful step.</p>
    </div>

    <div class="basis" role="group" aria-label="Income rhythm">
      <button type="button" data-basis="weekly" aria-pressed="true">Weekly income</button>
      <button type="button" data-basis="biweekly" aria-pressed="false">Biweekly income</button>
      <button type="button" data-basis="monthly" aria-pressed="false">Monthly income</button>
      <button type="button" data-basis="annual" aria-pressed="false">Annual income</button>
    </div>

    <div>
      <label for="income" id="income-label">Gross weekly income</label>
      <input id="income" inputmode="decimal" type="text" placeholder="$0.00" aria-describedby="income-note" autocomplete="off">
      <small id="income-note">Private by design: your income and calculated amount stay on this device and are never sent to <span data-church-name></span>.</small>
    </div>

    <div class="control">
      <div class="dial" id="dial"><strong id="percent-display">10%</strong></div>
      <div>
        <p class="control-label" id="percent-label">Biblical tithe</p>
        <input id="percent" type="range" min="0" max="100" step="1" value="10" aria-labelledby="percent-label">
        <div class="range-labels"><span>0%</span><span>20%</span><span>50%</span><span>100%</span></div>
        <p class="help" id="help"></p>
      </div>
    </div>

    <div class="result" aria-live="polite">
      <p class="result-label" id="result-label">Your calculated weekly tithe</p>
      <strong class="amount" id="result">$0.00</strong>
      <p id="daily">That is about $0.00 a day.</p>
      <p id="breakdown" hidden></p>
      <p id="detail">Choose your income rhythm, enter gross income, then adjust the percentage.</p>
    </div>

    <div class="actions">
      <button type="button" id="save">Copy and store amount to pray about</button>
      <a id="give-link" href="#" target="_blank" rel="noopener">Copy amount and set up a recurring gift</a>
    </div>
    <p class="message" id="message" aria-live="polite"></p>
    <p class="next-step">You can begin where you are and grow as God leads.</p>
  </section>
</div>

<script>
  /* ============================================================
     STEP 4: YOUR CHURCH SETTINGS
     ============================================================ */
  const CONFIG = {
    // Your church's name, used in the privacy note.
    churchName: "[YOUR CHURCH NAME]",

    // The page where people give online.
    // Planning Center example: "https://yourchurch.churchcenter.com/giving"
    givingUrl: "https://YOUR-GIVING-PAGE-URL",

    // Planning Center (Church Center) can pre-fill the amount from the link.
    // Leave as "amount" for Planning Center. Set to "" for any other
    // platform; the amount still gets copied so people can paste it.
    amountParam: "amount",

    // Button text for the giving link. Keep it plain. Most people
    // don't know the name of your giving software.
    giveButtonText: "Copy amount and set up a recurring gift",

    // Currency for the amounts.
    locale: "en-US",
    currency: "USD"
  };

  /* ---------- Calculator logic (no edits needed) ---------- */
  (function () {
    const $ = (id) => document.getElementById(id);
    const income = $("income"), percent = $("percent"), dial = $("dial");
    const giveLink = $("give-link"), message = $("message");
    const perYear = { weekly: 52, biweekly: 26, monthly: 12, annual: 1 };
    let basis = "weekly";

    document.querySelectorAll("[data-church-name]").forEach((el) => (el.textContent = CONFIG.churchName));
    giveLink.textContent = CONFIG.giveButtonText;

    const money = (n) => new Intl.NumberFormat(CONFIG.locale, { style: "currency", currency: CONFIG.currency }).format(n);
    const readIncome = () => Number(income.value.replace(/[^0-9.]/g, "")) || 0;
    const readPercent = () => Number(percent.value) || 0;

    // Amount per gift. Annual income is shown as a monthly gift.
    const giftAmount = () => {
      const g = (readIncome() * readPercent()) / 100;
      return basis === "annual" ? g / 12 : g;
    };

    const buildLink = (amt) => {
      if (!CONFIG.amountParam || !amt) return CONFIG.givingUrl;
      try {
        const u = new URL(CONFIG.givingUrl);
        u.searchParams.set(CONFIG.amountParam, amt.toFixed(2));
        return u.toString();
      } catch (e) {
        return CONFIG.givingUrl;
      }
    };

    function render() {
      const inc = readIncome(), pct = readPercent();
      const period = basis === "annual" ? "monthly" : basis;
      const amt = giftAmount();
      const yearly = (inc * pct) / 100 * perYear[basis];
      const tithe = basis === "annual" ? (inc * 0.1) / 12 : inc * 0.1;
      const offering = Math.max(0, amt - tithe);
      const pctText = pct + "%";

      dial.style.setProperty("--percent", String(pct));
      $("percent-display").textContent = pctText;
      percent.setAttribute("aria-valuetext", pctText + " giving");
      $("percent-label").textContent = pct === 10 ? "Biblical tithe" : "Giving percentage";
      $("result-label").textContent = pct === 10 ? `Your calculated ${period} tithe` : `Your total ${period} tithe and offering`;
      $("result").textContent = money(amt);
      $("daily").textContent = `That is about ${money(yearly / 365)} a day.`;
      giveLink.href = buildLink(amt);

      $("help").textContent =
        pct < 10 ? `Starting somewhere is worth celebrating. ${pctText} is not yet a full tithe, but it is a faithful place to begin.`
        : pct === 10 ? "10% is the biblical tithe, the Old Testament standard of trusting God with a tenth of your first fruits."
        : `${pctText} includes a full tithe and an offering above and beyond it.`;

      const breakdown = $("breakdown"), detail = $("detail");
      if (!inc) {
        breakdown.hidden = true;
        detail.textContent = "Choose your income rhythm, enter gross income, then adjust the percentage.";
      } else if (pct < 10) {
        breakdown.hidden = false;
        breakdown.textContent = `${money(amt)} is your current planned giving amount.`;
        detail.textContent = "Every generous step matters. Start here with joy and let God lead your growth toward the biblical tithe of 10%.";
      } else if (pct === 10) {
        breakdown.hidden = false;
        breakdown.textContent = `${money(tithe)} is the full tithe.`;
        detail.textContent = "A biblical tithe is the Old Testament standard of trusting God with a tenth of your first fruits.";
      } else {
        breakdown.hidden = false;
        breakdown.textContent = `${money(tithe)} is the tithe. ${money(offering)} is an offering above and beyond the tithe.`;
        detail.textContent = "This is a full tithe plus generosity above and beyond the tenth.";
      }
      sendHeight();
    }

    async function copy(amt) {
      try {
        if (navigator.clipboard) { await navigator.clipboard.writeText(money(amt)); return true; }
      } catch (e) {}
      return false;
    }

    $("save").addEventListener("click", async () => {
      const amt = giftAmount();
      if (!amt) { message.textContent = "Enter an income amount first so there is an amount to save."; return; }
      const ok = await copy(amt);
      try { localStorage.setItem("giving-calculator-amount", money(amt)); } catch (e) {}
      message.textContent = ok ? `${money(amt)} copied and ready to store.` : `${money(amt)} is your amount to pray about.`;
    });

    giveLink.addEventListener("click", async () => {
      const amt = giftAmount();
      if (!amt) { message.textContent = "Enter an income amount first, or give any amount on the next page."; return; }
      const ok = await copy(amt);
      message.textContent = ok ? `${money(amt)} copied. Paste it on the next page if it isn't already filled in, then choose how often you want to give.` : `Your giving amount is ${money(amt)}.`;
    });

    document.querySelectorAll("[data-basis]").forEach((btn) =>
      btn.addEventListener("click", () => {
        basis = btn.dataset.basis;
        document.querySelectorAll("[data-basis]").forEach((b) => b.setAttribute("aria-pressed", String(b === btn)));
        $("income-label").textContent = `Gross ${basis} income`;
        render();
      })
    );
    income.addEventListener("input", render);
    percent.addEventListener("input", render);

    // Lets the iframe embed resize itself to fit (see the iframe code).
    function sendHeight() {
      if (window.parent !== window) {
        window.parent.postMessage({ type: "giving-calculator-height", height: document.documentElement.scrollHeight }, "*");
      }
    }
    window.addEventListener("resize", sendHeight);
    window.addEventListener("load", sendHeight);

    render();
  })();
</script>
</body>
</html>
```

---

## iframe snippet

Use this when the website builder won't run a full page of code. Host `giving-calculator.html` first, then paste this into an embed or custom code block and replace `YOUR-HOSTED-CALCULATOR-URL` with the hosted link.

```html
<iframe
  id="giving-calculator"
  src="YOUR-HOSTED-CALCULATOR-URL"
  title="Giving calculator"
  style="width:100%; height:1500px; border:0; display:block;"
  loading="lazy"
  allow="clipboard-write">
</iframe>
<script>
  // Resizes the iframe to fit the calculator so there's no inner scrollbar.
  window.addEventListener("message", function (e) {
    if (e.data && e.data.type === "giving-calculator-height") {
      document.getElementById("giving-calculator").style.height = e.data.height + "px";
    }
  });
</script>
```

If the builder strips the `<script>` part, the iframe still works at a fixed height. Adjust `1500px` until there's no scrollbar. `allow="clipboard-write"` lets the copy buttons work inside the iframe. If copying is blocked anyway, the calculator shows the amount on screen.

---

Stuck? Kingdom IP will set it up for you for $50: kingdomip.org/resources/giving-calculator. Questions: hello@kingdomip.org.

*Scripture quotation from the Holy Bible, New International Version® NIV®. Copyright © 1973, 1978, 1984, 2011 by Biblica, Inc.® Used by permission. All rights reserved worldwide.*
